package javaapplication1;

public class ConnectionURL {
	public static String url = "redacted";
}
